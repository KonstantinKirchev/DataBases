DELETE FROM Users
WHERE Id = 7 OR Id = 9

DELETE FROM Groups
WHERE Name = 'Extra'


