SELECT convert(varchar, getdate(), 104)+' '+convert(varchar, getdate(), 114) AS DateTime
