UPDATE Users 
SET UserPassword = 'umna_parola' 
WHERE Id = 1 
 
 
UPDATE Groups 
SET Name = 'Forum users' 
WHERE Name = 'Users' 
