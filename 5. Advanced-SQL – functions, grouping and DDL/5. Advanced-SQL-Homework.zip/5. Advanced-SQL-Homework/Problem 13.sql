SELECT FirstName, LastName
FROM Employees
WHERE LEN(LastName) = 5