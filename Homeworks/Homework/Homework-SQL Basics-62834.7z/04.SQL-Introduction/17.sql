USE SoftUni;
GO

SELECT TOP 5 FirstName, MiddleName, LastName, JobTitle, Salary
FROM Employees;
GO