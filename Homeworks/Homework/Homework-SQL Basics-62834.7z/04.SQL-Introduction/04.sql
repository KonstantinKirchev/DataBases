USE SoftUni;
GO

SELECT * FROM Departments;