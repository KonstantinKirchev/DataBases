USE SoftUni;
GO

SELECT DISTINCT FirstName, MiddleName, LastName, Salary
FROM Employees;