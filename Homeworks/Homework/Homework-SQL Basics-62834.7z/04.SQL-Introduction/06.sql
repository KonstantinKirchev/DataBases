USE SoftUni;
GO

SELECT FirstName, LastName, Salary
FROM Employees