USE SoftUni;
GO

SELECT *
FROM Employees
WHERE JobTitle = 'Sales Representative';
GO