USE SoftUni;
GO

SELECT (FirstName + '.' + LastName + '@softuni.bg') as [Full Email Address]
FROM Employees;