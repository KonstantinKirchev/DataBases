USE SoftUni;
GO

SELECT Name FROM Departments;