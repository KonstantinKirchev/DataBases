SELECT Name
FROM Departments