SELECT FirstName+'.'+LastName+'@softuni.bg' AS [Full Email Addresses]
FROM Employees