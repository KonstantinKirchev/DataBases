SELECT FirstName
FROM Employees
WHERE FirstName LIKE 'SA%'