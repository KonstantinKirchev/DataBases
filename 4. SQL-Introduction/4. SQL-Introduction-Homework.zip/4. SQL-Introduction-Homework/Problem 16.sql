SELECT *
FROM Employees
WHERE Salary > 50000
ORDER BY Salary DESC