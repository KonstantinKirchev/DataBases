SELECT FirstName+' '+LastName AS FullName
FROM Employees