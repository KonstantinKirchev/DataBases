SELECT *
FROM Departments