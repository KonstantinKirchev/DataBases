SELECT LastName
FROM Employees
WHERE LastName LIKE '%ei%'