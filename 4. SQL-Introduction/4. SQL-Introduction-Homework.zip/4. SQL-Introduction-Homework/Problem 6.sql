SELECT FirstName, LastName, Salary
FROM Employees