SELECT *
FROM Employees
WHERE JobTitle = 'Sales Representative'