SELECT Name
FROM Departments
UNION
SELECT Name
FROM Towns